# EXIF interaction research evidence

This evidence packet is distributed as six independently valid ZIP archives. Extract all six into the same folder, preserving their directory structure. Open docs/research/reference-evidence/index.html for the portable evidence viewer, or docs/research/EXIF-INTERACTION-REFERENCE-STUDY.md for the report.

Archive 01 contains the report, viewer/index, shared logs/manifests and historical diagnostics. Archives 02–06 contain each original reference's screenshots, recordings and scroll diagnostics. Together they contain all 211 live screenshots and 29 MP4 recordings.

Research only: no website source change, merge or deployment. Mobile checks are Chromium emulation, not physical-device/Safari validation. See the report for observations and limitations.
